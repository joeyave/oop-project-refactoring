#include <iostream>

int main()
{
	const int sec_in_three_min = 3 * 60;
	const int result = sec_in_three_min * 60;

	std::cout << "result: " << result << std::endl;
}
